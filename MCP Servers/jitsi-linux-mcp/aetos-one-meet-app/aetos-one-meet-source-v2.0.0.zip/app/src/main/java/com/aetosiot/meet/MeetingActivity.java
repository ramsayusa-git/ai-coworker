package com.aetosiot.meet;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;

import java.net.URL;
import java.util.HashMap;

/**
 * Native Jitsi meeting screen. Extends the SDK activity so we can:
 *  - show over the lock screen + turn the screen on (pager behaviour),
 *  - stop the incoming ring once the conference is joined,
 *  - return to Standby when the meeting ends.
 */
public class MeetingActivity extends JitsiMeetActivity {

    public static void launch(Context c, String room, String jwt, String title) {
        JitsiMeetConferenceOptions options = buildOptions(room, jwt, title);
        if (options == null) return;
        Intent intent = new Intent(c, MeetingActivity.class);
        intent.setAction("org.jitsi.meet.CONFERENCE");
        intent.putExtra("JitsiMeetConferenceOptions", options);
        if (!(c instanceof android.app.Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        try {
            c.startActivity(intent);
        } catch (Exception ignored) {
            // Background activity-start restrictions: the full-screen-intent
            // notification posted by IncomingCallNotifier covers this case.
        }
    }

    public static JitsiMeetConferenceOptions buildOptions(String room, String jwt, String title) {
        try {
            JitsiMeetConferenceOptions.Builder b = new JitsiMeetConferenceOptions.Builder()
                    .setServerURL(new URL(Api.BASE))
                    .setRoom(room)
                    .setAudioMuted(false)
                    .setVideoMuted(false)
                    .setFeatureFlag("prejoinpage.enabled", false)
                    .setFeatureFlag("unsaferoomwarning.enabled", false)
                    .setFeatureFlag("android.screensharing.enabled", true)
                    .setFeatureFlag("pip.enabled", true)
                    .setFeatureFlag("invite.enabled", false)
                    .setFeatureFlag("add-people.enabled", false)
                    .setFeatureFlag("calendar.enabled", false)
                    .setFeatureFlag("call-integration.enabled", false);
            if (jwt != null && !jwt.isEmpty()) b.setToken(jwt);
            if (title != null && !title.isEmpty()) b.setConfigOverride("subject", title);
            return b.build();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Show over the lock screen and wake the display (pre-API-27 path;
        // API 27+ uses the manifest showWhenLocked/turnScreenOn attributes).
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        super.onCreate(savedInstanceState);
        IncomingCallNotifier.cancel(this);
    }

    @Override
    public void onConferenceJoined(HashMap<String, Object> extraData) {
        IncomingRinger.stopRinging();
        IncomingCallNotifier.cancel(this);
        super.onConferenceJoined(extraData);
    }

    @Override
    public void onConferenceTerminated(HashMap<String, Object> extraData) {
        IncomingRinger.stopRinging();
        super.onConferenceTerminated(extraData);
        // Back to standby so the pager keeps waiting for the next meeting.
        Intent i = new Intent(this, StandbyActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }
}
