package com.aetosiot.meet;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Thin JSON client for the Aetos One portal API on meet.aetosiot.com. */
public class Api {
    public static final String BASE = "https://meet.aetosiot.com";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private static OkHttpClient client;

    public static synchronized OkHttpClient http() {
        if (client == null) {
            client = new OkHttpClient.Builder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build();
        }
        return client;
    }

    /** OkHttp client with no read timeout, for the long-lived SSE stream. */
    public static OkHttpClient sseHttp() {
        return http().newBuilder()
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .retryOnConnectionFailure(true)
                .build();
    }

    public interface JsonCb {
        void ok(JSONObject body);
        void fail(String error);
    }

    private static void run(Request req, JsonCb cb) {
        Handler main = new Handler(Looper.getMainLooper());
        http().newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                main.post(() -> cb.fail(e.getMessage() == null ? "network error" : e.getMessage()));
            }
            @Override public void onResponse(Call call, Response resp) {
                try (Response r = resp) {
                    String text = r.body() != null ? r.body().string() : "";
                    JSONObject j;
                    try {
                        j = text.trim().startsWith("[")
                                ? new JSONObject().put("items", new JSONArray(text))
                                : new JSONObject(text);
                    } catch (Exception pe) {
                        j = new JSONObject();
                    }
                    if (r.isSuccessful()) {
                        JSONObject fj = j;
                        main.post(() -> cb.ok(fj));
                    } else {
                        String err = j.optString("error", "HTTP " + r.code());
                        main.post(() -> cb.fail(err));
                    }
                } catch (Exception e) {
                    main.post(() -> cb.fail(String.valueOf(e.getMessage())));
                }
            }
        });
    }

    private static Request.Builder authed(Context c, String path) {
        Request.Builder b = new Request.Builder().url(BASE + path);
        String t = Session.token(c);
        if (t != null) b.header("Authorization", "Bearer " + t);
        return b;
    }

    // ---- endpoints ----

    public static void login(String user, String pass, JsonCb cb) {
        JSONObject body = new JSONObject();
        try {
            body.put("username", user);
            body.put("email", user);
            body.put("password", pass);
        } catch (Exception ignored) {}
        Request req = new Request.Builder()
                .url(BASE + "/api/auth/login")
                .post(RequestBody.create(body.toString(), JSON))
                .build();
        run(req, cb);
    }

    public static void me(Context c, JsonCb cb) {
        run(authed(c, "/api/auth/me").get().build(), cb);
    }

    public static void roomsMine(Context c, JsonCb cb) {
        run(authed(c, "/api/rooms/mine").get().build(), cb);
    }

    public static void meetingToken(Context c, String roomSlug, JsonCb cb) {
        JSONObject body = new JSONObject();
        try { body.put("room", roomSlug); } catch (Exception ignored) {}
        run(authed(c, "/api/meetings/token")
                .post(RequestBody.create(body.toString(), JSON)).build(), cb);
    }

    public static void registerDevice(Context c, String fcmToken, JsonCb cb) {
        JSONObject body = new JSONObject();
        try {
            body.put("token", fcmToken);
            body.put("platform", "android");
        } catch (Exception ignored) {}
        run(authed(c, "/api/devices/register")
                .post(RequestBody.create(body.toString(), JSON)).build(), cb);
    }

    public static void unregisterDevice(Context c, String fcmToken, JsonCb cb) {
        JSONObject body = new JSONObject();
        try { body.put("token", fcmToken); } catch (Exception ignored) {}
        run(authed(c, "/api/devices/unregister")
                .post(RequestBody.create(body.toString(), JSON)).build(), cb);
    }
}
