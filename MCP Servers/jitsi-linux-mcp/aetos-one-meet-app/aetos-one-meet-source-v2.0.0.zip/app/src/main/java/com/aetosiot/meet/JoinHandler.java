package com.aetosiot.meet;

import android.content.Context;
import android.net.Uri;

/**
 * Central entry point for every "a meeting started, join it" signal
 * (SSE push, FCM push, manual join). Parses the portal's /joinmeeting URL
 * into room + JWT for the native SDK, dedupes double deliveries
 * (SSE and FCM both fire when the app is alive), rings, and launches
 * the native meeting.
 */
public class JoinHandler {
    private static final long DEDUPE_WINDOW_MS = 30_000;
    private static String lastRoom = null;
    private static long lastAt = 0;

    public static synchronized void handleJoinUrl(Context c, String url, String title, boolean ring) {
        String room = null;
        String jwt = null;
        try {
            Uri u = Uri.parse(url);
            room = u.getQueryParameter("name");
            if (room == null || room.isEmpty()) room = u.getQueryParameter("room");
            jwt = u.getQueryParameter("jwt");
            if (room == null || room.isEmpty()) {
                // Bare meeting URL form: https://host/<Room>
                String path = u.getPath();
                if (path != null && path.length() > 1 && !path.contains("joinmeeting")) {
                    room = path.substring(1);
                }
            }
        } catch (Exception ignored) {}

        if (room == null || room.isEmpty()) return;

        long now = System.currentTimeMillis();
        if (room.equals(lastRoom) && (now - lastAt) < DEDUPE_WINDOW_MS) {
            return; // already handling this meeting
        }
        lastRoom = room;
        lastAt = now;

        if (ring) {
            IncomingRinger.startRinging(c);
            // Full-screen intent covers locked screens and Android's
            // background activity-start restrictions.
            IncomingCallNotifier.show(c, room, jwt, title);
        }
        MeetingActivity.launch(c, room, jwt, title);
    }

    /** A manual join also counts as a claim, so the SSE push that follows is ignored. */
    public static synchronized void markManualJoin(String room) {
        lastRoom = room;
        lastAt = System.currentTimeMillis();
    }
}
