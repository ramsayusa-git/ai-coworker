package com.aetosiot.meet;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;

/**
 * Incoming-call style notification with a full-screen intent, so a meeting
 * push can take over the screen even when the device is locked / screen off,
 * and survives Android's background activity-start restrictions.
 */
public class IncomingCallNotifier {
    public static final int NOTIF_ID = 2002;

    public static void show(Context c, String room, String jwt, String title) {
        JitsiMeetConferenceOptions options = MeetingActivity.buildOptions(room, jwt, title);
        if (options == null) return;

        Intent full = new Intent(c, MeetingActivity.class);
        full.setAction("org.jitsi.meet.CONFERENCE");
        full.putExtra("JitsiMeetConferenceOptions", options);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent fullPi = PendingIntent.getActivity(c, 1, full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new NotificationCompat.Builder(c, App.CH_INCOMING)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title == null || title.isEmpty() ? "Meeting started" : title)
                .setContentText("Aetos One Meet — joining your meeting")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setAutoCancel(true)
                .setOngoing(true)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .build();

        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, n);
    }

    public static void cancel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIF_ID);
    }
}
