package com.aetosiot.meet;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import org.json.JSONObject;

import okhttp3.Request;
import okhttp3.Response;
import okhttp3.sse.EventSource;
import okhttp3.sse.EventSourceListener;
import okhttp3.sse.EventSources;

/**
 * Foreground service holding the portal presence connection (SSE /api/live).
 * Keeps the user "online" and receives 'join' pushes while the app is
 * minimised or the screen is off. (FCM covers the force-closed case.)
 */
public class StandbyService extends Service {
    private static final int NOTIF_ID = 1001;
    private static volatile boolean connected = false;
    private static volatile boolean running = false;

    private EventSource eventSource;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int retryDelayMs = 2000;
    private boolean stopped = false;

    public static boolean isConnected() { return connected; }

    public static void start(Context c) {
        Intent i = new Intent(c, StandbyService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception ignored) {
            // Background FGS start restrictions (e.g. from boot on Android 15):
            // BootReceiver falls back to a tap-to-resume notification.
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, n);
        }
        if (!running) {
            running = true;
            connectSse();
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, StandbyActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, App.CH_STANDBY)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notif_standby_text))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setOngoing(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void connectSse() {
        if (stopped) return;
        String token = Session.token(this);
        if (token == null) { stopSelf(); return; }

        Request req = new Request.Builder()
                .url(Api.BASE + "/api/live?token=" + token)
                .header("Accept", "text/event-stream")
                .build();

        eventSource = EventSources.createFactory(Api.sseHttp())
                .newEventSource(req, new EventSourceListener() {
                    @Override public void onOpen(EventSource es, Response response) {
                        connected = true;
                        retryDelayMs = 2000;
                        broadcastStatus();
                    }

                    @Override public void onEvent(EventSource es, String id, String type, String data) {
                        if (type == null) type = "";
                        try {
                            JSONObject d = new JSONObject(data);
                            String kind = type.isEmpty() ? d.optString("type", "") : type;
                            if ("join".equals(kind)) {
                                String url = d.optString("url", null);
                                String title = d.optString("title", d.optString("room", "Meeting"));
                                if (url != null) {
                                    JoinHandler.handleJoinUrl(StandbyService.this, url, title, true);
                                }
                            }
                        } catch (Exception ignored) {}
                    }

                    @Override public void onClosed(EventSource es) {
                        connected = false;
                        broadcastStatus();
                        scheduleReconnect();
                    }

                    @Override public void onFailure(EventSource es, Throwable t, Response response) {
                        connected = false;
                        broadcastStatus();
                        scheduleReconnect();
                    }
                });
    }

    private void scheduleReconnect() {
        if (stopped) return;
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(() -> {
            if (!stopped) connectSse();
        }, retryDelayMs);
        retryDelayMs = Math.min(retryDelayMs * 2, 30000);
    }

    private void broadcastStatus() {
        Intent i = new Intent(StandbyActivity.ACTION_STATUS);
        i.putExtra("connected", connected);
        LocalBroadcastManager.getInstance(this).sendBroadcast(i);
    }

    @Override
    public void onDestroy() {
        stopped = true;
        running = false;
        connected = false;
        handler.removeCallbacksAndMessages(null);
        if (eventSource != null) eventSource.cancel();
        broadcastStatus();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
