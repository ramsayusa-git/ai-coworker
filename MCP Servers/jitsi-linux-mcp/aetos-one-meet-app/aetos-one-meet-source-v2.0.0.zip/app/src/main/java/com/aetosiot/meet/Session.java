package com.aetosiot.meet;

import android.content.Context;
import android.content.SharedPreferences;

/** Persistent session store (token + display name), same trust level as the web app's localStorage. */
public class Session {
    private static final String PREFS = "aetos_session";

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String token(Context c) { return p(c).getString("token", null); }
    public static String displayName(Context c) { return p(c).getString("name", ""); }
    public static String fcmToken(Context c) { return p(c).getString("fcm", null); }

    public static void save(Context c, String token, String name) {
        p(c).edit().putString("token", token).putString("name", name == null ? "" : name).apply();
    }

    public static void saveFcmToken(Context c, String t) {
        p(c).edit().putString("fcm", t).apply();
    }

    public static void clear(Context c) {
        p(c).edit().remove("token").remove("name").apply();
    }

    public static boolean signedIn(Context c) { return token(c) != null; }
}
