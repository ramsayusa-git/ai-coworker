package com.aetosiot.meet;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.media.AudioAttributes;
import android.os.Build;

public class App extends Application {
    public static final String CH_STANDBY = "aetos_standby";
    public static final String CH_INCOMING = "aetos_incoming";

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);

            NotificationChannel standby = new NotificationChannel(
                    CH_STANDBY, getString(R.string.notif_channel_standby),
                    NotificationManager.IMPORTANCE_LOW);
            standby.setShowBadge(false);
            nm.createNotificationChannel(standby);

            NotificationChannel incoming = new NotificationChannel(
                    CH_INCOMING, getString(R.string.notif_channel_incoming),
                    NotificationManager.IMPORTANCE_HIGH);
            incoming.setDescription("Rings and wakes the device when a meeting starts");
            incoming.setSound(null, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
            incoming.enableVibration(true);
            incoming.setBypassDnd(true);
            nm.createNotificationChannel(incoming);
        }
    }
}
