package com.aetosiot.meet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Session.signedIn(this)) {
            goStandby();
            return;
        }

        setContentView(R.layout.activity_login);
        EditText inUser = findViewById(R.id.inUser);
        EditText inPass = findViewById(R.id.inPass);
        Button btn = findViewById(R.id.btnLogin);
        TextView err = findViewById(R.id.txtError);

        btn.setOnClickListener(v -> {
            String u = inUser.getText().toString().trim();
            String p = inPass.getText().toString();
            if (u.isEmpty() || p.isEmpty()) {
                err.setText("Enter your username and password");
                err.setVisibility(View.VISIBLE);
                return;
            }
            btn.setEnabled(false);
            err.setVisibility(View.GONE);
            Api.login(u, p, new Api.JsonCb() {
                @Override public void ok(JSONObject body) {
                    String token = body.optString("token",
                            body.optString("jwt", null));
                    if (token == null || token.isEmpty()) {
                        fail("Unexpected response from server");
                        return;
                    }
                    JSONObject user = body.optJSONObject("user");
                    String name = user != null
                            ? user.optString("name", user.optString("username", u))
                            : body.optString("name", u);
                    Session.save(LoginActivity.this, token, name);
                    DeviceRegistrar.register(LoginActivity.this);
                    goStandby();
                }
                @Override public void fail(String e) {
                    btn.setEnabled(true);
                    err.setText("Sign-in failed: " + e);
                    err.setVisibility(View.VISIBLE);
                }
            });
        });
    }

    private void goStandby() {
        startActivity(new Intent(this, StandbyActivity.class));
        finish();
    }
}
