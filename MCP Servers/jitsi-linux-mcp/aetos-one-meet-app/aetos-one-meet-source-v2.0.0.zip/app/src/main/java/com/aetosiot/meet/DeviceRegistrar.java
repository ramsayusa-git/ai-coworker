package com.aetosiot.meet;

import android.content.Context;

import org.json.JSONObject;

/**
 * Registers this device's FCM token with the portal (/api/devices/register).
 * No-ops cleanly when the build has no google-services.json (Firebase not
 * initialized) or when Play services are unavailable.
 */
public class DeviceRegistrar {

    public static void register(Context c) {
        if (!Session.signedIn(c)) return;
        try {
            if (com.google.firebase.FirebaseApp.getApps(c).isEmpty()) return;
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                    .addOnSuccessListener(token -> {
                        if (token == null || token.isEmpty()) return;
                        Session.saveFcmToken(c, token);
                        Api.registerDevice(c, token, new Api.JsonCb() {
                            @Override public void ok(JSONObject body) {}
                            @Override public void fail(String error) {}
                        });
                    });
        } catch (Throwable ignored) {
            // Firebase classes present but not configured — FCM disabled build.
        }
    }
}
