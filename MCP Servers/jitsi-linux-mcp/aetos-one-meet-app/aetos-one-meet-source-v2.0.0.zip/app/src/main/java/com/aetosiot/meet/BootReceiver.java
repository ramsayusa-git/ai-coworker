package com.aetosiot.meet;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

/** Restarts standby after a reboot. On Android 15+ a dataSync FGS cannot be
 *  started from BOOT_COMPLETED, so we fall back to a tap-to-resume notification. */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Session.signedIn(context)) return;
        try {
            StandbyService.start(context);
        } catch (Exception ignored) {}

        // If the service could not come up (background-start restrictions),
        // give the user a one-tap way back to standby.
        try {
            Intent open = new Intent(context, StandbyActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(context, 2, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification n = new NotificationCompat.Builder(context, App.CH_STANDBY)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Aetos One Meet")
                    .setContentText("Tap to resume meeting standby")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(3003, n);
        } catch (Exception ignored) {}
    }
}
