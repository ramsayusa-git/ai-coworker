package com.aetosiot.meet;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.util.Map;

/**
 * Wakes the app from ANY state (including force-closed) on a high-priority
 * data push from the portal: {type:'join', room, title, url}.
 */
public class FcmService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage message) {
        if (!Session.signedIn(this)) return;
        Map<String, String> data = message.getData();
        String type = data.get("type");
        if (!"join".equals(type)) return;
        String url = data.get("url");
        String title = data.get("title");
        if (title == null) title = data.get("room");
        if (url != null) {
            JoinHandler.handleJoinUrl(this, url, title == null ? "Meeting" : title, true);
        }
        // Bring the standby connection back up too.
        StandbyService.start(this);
    }

    @Override
    public void onNewToken(String token) {
        Session.saveFcmToken(this, token);
        if (Session.signedIn(this)) {
            Api.registerDevice(this, token, new Api.JsonCb() {
                @Override public void ok(JSONObject body) {}
                @Override public void fail(String error) {}
            });
        }
    }
}
