package com.aetosiot.meet;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Plays the device ringtone (looping) + vibration for ~8s when a meeting comes in. */
public class IncomingRinger {
    private static MediaPlayer player;
    private static Vibrator vibrator;
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static final long RING_MS = 8000;

    public static synchronized void startRinging(Context c) {
        stopRinging();
        try {
            Uri tone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (tone != null) {
                player = new MediaPlayer();
                player.setDataSource(c.getApplicationContext(), tone);
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
                player.setLooping(true);
                player.prepare();
                player.start();
            }
        } catch (Exception ignored) {}

        try {
            vibrator = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = {0, 600, 400};
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                } else {
                    vibrator.vibrate(pattern, 0);
                }
            }
        } catch (Exception ignored) {}

        handler.postDelayed(IncomingRinger::stopRinging, RING_MS);
    }

    public static synchronized void stopRinging() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (player != null) { player.stop(); player.release(); }
        } catch (Exception ignored) {}
        player = null;
        try {
            if (vibrator != null) vibrator.cancel();
        } catch (Exception ignored) {}
        vibrator = null;
    }
}
