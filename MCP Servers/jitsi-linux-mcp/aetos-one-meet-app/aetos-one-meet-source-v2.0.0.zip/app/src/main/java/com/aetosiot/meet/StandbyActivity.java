package com.aetosiot.meet;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class StandbyActivity extends AppCompatActivity {
    public static final String ACTION_STATUS = "com.aetosiot.meet.STANDBY_STATUS";

    private TextView txtStatus;
    private android.view.View dot;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            boolean connected = intent.getBooleanExtra("connected", false);
            showStatus(connected);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!Session.signedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_standby);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        TextView hello = findViewById(R.id.txtHello);
        String name = Session.displayName(this);
        hello.setText(name.isEmpty() ? getString(R.string.standby_title) : name);

        txtStatus = findViewById(R.id.txtStatus);
        dot = findViewById(R.id.dot);

        Button joinNow = findViewById(R.id.btnJoinNow);
        joinNow.setOnClickListener(v -> joinMyMeeting());

        Button signOut = findViewById(R.id.btnSignOut);
        signOut.setOnClickListener(v -> {
            String fcm = Session.fcmToken(this);
            if (fcm != null) Api.unregisterDevice(this, fcm, new Api.JsonCb() {
                @Override public void ok(JSONObject body) {}
                @Override public void fail(String error) {}
            });
            stopService(new Intent(this, StandbyService.class));
            Session.clear(this);
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        requestNeededPermissions();
        requestBatteryExemption();
        StandbyService.start(this);
        DeviceRegistrar.register(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(statusReceiver, new IntentFilter(ACTION_STATUS));
        showStatus(StandbyService.isConnected());
        // Nudge the service in case the OS killed it while we were away.
        if (Session.signedIn(this)) StandbyService.start(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(statusReceiver);
    }

    private void showStatus(boolean connected) {
        if (txtStatus == null) return;
        txtStatus.setText(connected ? R.string.standby_waiting : R.string.standby_disconnected);
        dot.setBackgroundResource(connected ? R.drawable.dot_green : R.drawable.dot_red);
    }

    /** Ask for everything an unattended auto-join needs, up front. */
    private void requestNeededPermissions() {
        ArrayList<String> need = new ArrayList<>();
        for (String perm : new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                need.add(perm);
            }
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), 71);
        }
    }

    private void requestBatteryExemption() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                } catch (Exception ignored) {}
            }
        }
    }

    /** Manual "Join my meeting now": first of my rooms -> mint token -> native meeting. */
    private void joinMyMeeting() {
        Api.roomsMine(this, new Api.JsonCb() {
            @Override public void ok(JSONObject body) {
                JSONArray rooms = body.optJSONArray("items");
                if (rooms == null) rooms = body.optJSONArray("rooms");
                if (rooms == null || rooms.length() == 0) {
                    Toast.makeText(StandbyActivity.this, "No rooms assigned to you", Toast.LENGTH_LONG).show();
                    return;
                }
                JSONObject room = rooms.optJSONObject(0);
                if (room == null) return;
                String slug = room.optString("slug", room.optString("name", ""));
                String title = room.optString("name", slug);
                if (slug.isEmpty()) {
                    Toast.makeText(StandbyActivity.this, "Unexpected rooms response", Toast.LENGTH_LONG).show();
                    return;
                }
                Api.meetingToken(StandbyActivity.this, slug, new Api.JsonCb() {
                    @Override public void ok(JSONObject tok) {
                        String jwt = tok.optString("token", tok.optString("jwt", null));
                        String url = tok.optString("url", null);
                        if (jwt == null && url == null) {
                            Toast.makeText(StandbyActivity.this, "Could not get a meeting token", Toast.LENGTH_LONG).show();
                            return;
                        }
                        JoinHandler.markManualJoin(slug);
                        if (url != null && jwt == null) {
                            JoinHandler.handleJoinUrl(StandbyActivity.this, url, title, false);
                        } else {
                            MeetingActivity.launch(StandbyActivity.this, slug, jwt, title);
                        }
                    }
                    @Override public void fail(String e) {
                        Toast.makeText(StandbyActivity.this, "Token error: " + e, Toast.LENGTH_LONG).show();
                    }
                });
            }
            @Override public void fail(String e) {
                Toast.makeText(StandbyActivity.this, "Rooms error: " + e, Toast.LENGTH_LONG).show();
            }
        });
    }
}
