#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

#define AUDIO_INPUT_SAMPLE_RATE  24000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

// --- Audio codec (ES8311) -------------------------------------------------
// CONFIRMED from the stock firmware dump: this board uses an ES8311 I2C
// audio codec (Es8311AudioCodec class + "es8311_audio_codec.cc" string).
// The pin numbers below are NOT confirmed for this exact PCB -- they are a
// placeholder copied from the closest known-working public ESP32-C3 board
// (kevin-c3), which is architecturally the closest match we found (same
// ES8311 codec, same RMT-driven addressable LED). Verify/adjust via an I2C
// bus scan + physical continuity check, same approach used for the AI-Pin
// device's audio pins.
#define AUDIO_I2S_GPIO_MCLK GPIO_NUM_10
#define AUDIO_I2S_GPIO_WS   GPIO_NUM_12
#define AUDIO_I2S_GPIO_BCLK GPIO_NUM_8
#define AUDIO_I2S_GPIO_DIN  GPIO_NUM_7
#define AUDIO_I2S_GPIO_DOUT GPIO_NUM_11

#define AUDIO_CODEC_PA_PIN       GPIO_NUM_13
#define AUDIO_CODEC_I2C_SDA_PIN  GPIO_NUM_0
#define AUDIO_CODEC_I2C_SCL_PIN  GPIO_NUM_1
#define AUDIO_CODEC_ES8311_ADDR  ES8311_CODEC_DEFAULT_ADDR

// --- LED (addressable strip via RMT) --------------------------------------
// SETTLED 22 Aug 2026, night (v29): **GPIO9**, found empirically after a
// firmware GPIO-sweep diagnostic (v25-v28) blinked candidate pins one at a
// time and the user confirmed the real edge light-pipe LED blinked ONLY
// during the GPIO9 test window ("great blue light blinked") -- GPIO2/4/5/6
// all produced nothing. This also matches the corrected stock-binary
// disassembly trace (stock's LED wrapper constructor's one call site loads
// literal 9 into the gpio argument, count=1) AND explains the entire
// button saga: GPIO9 was never really the button's pin -- stock's real
// button trigger is the CI1302 UART packet (see esp32c3_chenglong_board.cc),
// and this pin belongs to the LED. The old GPIO5 value was a never-verified
// placeholder copied from kevin-c3.
// NOTE: GPIO9 is also the ESP32-C3 bootstrap pin -- fine for an output-only
// RMT data line during normal operation, but the reason the chip must not
// be reset while external hardware holds this line low.
#define BUILTIN_LED_GPIO GPIO_NUM_9

// --- Buttons ---------------------------------------------------------------
// SETTLED 22 Aug 2026 (superseding the GPIO4/active-high experiment tried
// earlier the same evening -- see the button-remap section in
// xiaozhi-c3-pendant-chenglong.md project memory for the full story):
// MAIN_BUTTON_GPIO = GPIO9, default (active-low) polarity. This was
// determined authoritatively by disassembling the STOCK firmware's own
// compiled code (not by physical GPIO scanning, which had become unreliable
// and contradictory across several rounds of live testing): located the
// exact machine-code bytes of Button::Button(gpio_num_t, bool) inside the
// vendor's own flash dump (byte-for-byte identical to this codebase's own
// compiled constructor, confirming same source/toolchain), found its
// single call site, and read the two immediate values loaded into
// registers right before the call: gpio_num=9, active_high=false. Since
// the user confirms stock firmware works correctly using ONLY the external
// "Power and wake up" button with the case fully closed, and that is
// provably the only GPIO+polarity stock firmware ever reads a button on,
// this pin/polarity pairing is authoritative -- more reliable than the
// live physical GPIO scan, which produced one clean GPIO4 pulse early on
// but could not be reproduced across five subsequent careful test rounds.
// The earlier photo-based belief that the "boot"-silkscreened switch (this
// same GPIO9 net) is unreachable once the case is closed was an incorrect
// visual inference -- the electrical evidence from the working stock
// firmware overrides it.
// SUPERSEDED 22 Aug 2026, night (v29): there is NO GPIO button on this
// board at all. GPIO9 (the pin stock's vestigial Button(9,false) object
// pointed at, and which this project also used for its Button) turned out
// to be the addressable LED's data pin (see BUILTIN_LED_GPIO above). The
// real, only button trigger is the 8-byte UART packet from the CI1302
// companion chip (see esp32c3_chenglong_board.cc) -- live-confirmed with
// full real conversations. The one early "GPIO9 press worked once" event
// was almost certainly the press glitching the shared LED/bootstrap line
// in a way the button driver happened to read as a click -- never
// reproducible, now explained. No MAIN_BUTTON_GPIO is defined anymore;
// do not re-add a GPIO Button without evidence stronger than the v25-v28
// LED GPIO sweep that settled this.

// --- Battery (ADC) -----------------------------------------------------
// CONFIRMED from the binary: battery/coin-cell level is read via adc_oneshot.
// Channel/pin below is a placeholder -- GPIO3 = ADC1_CHANNEL_3 on ESP32-C3.
#define BATTERY_ADC_CHANNEL ADC_CHANNEL_3

// --- Companion voice chip (ChipIntelli CI1302) UART -------------------
// CONFIRMED from the binary (exact literal pin numbers recovered from an
// ESP_ERROR_CHECK-embedded assertion string: uart_set_pin(UART_NUM_0,
// GPIO_NUM_21, GPIO_NUM_20, ...)). Not a guess.
#define VENDOR_UART_TX_PIN GPIO_NUM_21
#define VENDOR_UART_RX_PIN GPIO_NUM_20

#endif // _BOARD_CONFIG_H_
