// esp32c3-chenglong: custom board profile for the "VA"/vacloud round pendant
// (ESP32-C3, MAC b4:3a:45:42:1f:34).
//
// This is a from-scratch reconstruction, not a copy of the original vendor
// firmware source (which is private and was never published). It was built
// from facts reverse-engineered out of a full flash dump of the stock
// firmware (project "xiaozhi" v1.5.8, board class "Esp32c3ChenglongBoard"):
// an ES8311 I2C audio codec, an addressable RGB LED driven via RMT on GPIO9
// (settled empirically 22 Aug 2026 night, v29 -- see config.h), ADC-based
// battery sensing, and a companion ChipIntelli CI1302 voice chip wired to
// UART0 (TX=GPIO21, RX=GPIO20, exact literal values recovered from the
// binary).
//
// Button behavior (FINAL, v29 -- see xiaozhi-c3-pendant-chenglong.md project
// memory for the full investigation): this board has NO GPIO button. The
// one and only button trigger is an 8-byte packet over UART0 from the
// CI1302 companion voice chip ("收到按键请求，开始对话" / "received
// button-press request, start conversation"), discovered by comparing a
// known-good stock unit's live log side by side with this firmware, then
// sniffing our own hardware's UART0 RX (GPIO20): 9600 baud 8N1, packet
// `A5 FA 00 82 01 00 0A FB`, captured identically on separate presses and
// since confirmed through full real conversations. GPIO9, which both this
// project and stock's vestigial Button(9,false) object once treated as a
// button pin, is actually the LED data line (see config.h).

#include "wifi_board.h"
#include "audio_codecs/es8311_audio_codec.h"
#include "application.h"
#include "config.h"
#include "iot/thing_manager.h"
#include "led/circular_strip.h"

#include <wifi_station.h>
#include <esp_log.h>
#include <esp_efuse_table.h>
#include <driver/i2c_master.h>
#include <driver/uart.h>
#include <esp_adc/adc_oneshot.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <cstring>

#define TAG "Esp32C3ChenglongBoard"

// The real, confirmed button-press packet from the CI1302 companion chip,
// captured live off our own hardware's UART0 RX line (9600 baud 8N1,
// GPIO20): A5 FA 00 82 01 00 0A FB. Matched as a byte-exact signature --
// good enough given it was reproduced identically across separate presses.
static const uint8_t kButtonPressPacket[] = {0xA5, 0xFA, 0x00, 0x82, 0x01, 0x00, 0x0A, 0xFB};
static const size_t kButtonPressPacketLen = sizeof(kButtonPressPacket);

class Esp32C3ChenglongBoard : public WifiBoard {
private:
    i2c_master_bus_handle_t codec_i2c_bus_;
    CircularStrip* led_strip_;
    adc_oneshot_unit_handle_t battery_adc_handle_ = nullptr;

    void InitializeCodecI2c() {
        i2c_master_bus_config_t i2c_bus_cfg = {
            .i2c_port = I2C_NUM_0,
            .sda_io_num = AUDIO_CODEC_I2C_SDA_PIN,
            .scl_io_num = AUDIO_CODEC_I2C_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_bus_cfg, &codec_i2c_bus_));
    }

    void InitializeBatteryAdc() {
        adc_oneshot_unit_init_cfg_t init_config = {
            .unit_id = ADC_UNIT_1,
            .ulp_mode = ADC_ULP_MODE_DISABLE,
        };
        ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config, &battery_adc_handle_));

        adc_oneshot_chan_cfg_t chan_config = {
            .atten = ADC_ATTEN_DB_12,
            .bitwidth = ADC_BITWIDTH_12,
        };
        ESP_ERROR_CHECK(adc_oneshot_config_channel(battery_adc_handle_, BATTERY_ADC_CHANNEL, &chan_config));
    }

    // The board's ONLY button trigger (v29): the CI1302 UART packet handled
    // in UartListenTask() below. There is no GPIO button on this PCB --
    // GPIO9, previously (mis)used as one, is actually the LED data pin
    // (see config.h).
    void HandleButtonPress() {
        auto& app = Application::GetInstance();
        if (app.GetDeviceState() == kDeviceStateStarting && !WifiStation::GetInstance().IsConnected()) {
            ResetWifiConfiguration();
        } else {
            app.ToggleChatState();
        }
    }

    // Listens on UART0 (TX=GPIO21, RX=GPIO20, 9600 baud 8N1) for the CI1302
    // companion chip's button-press packet and treats it exactly like a
    // main-button click. This is the real, primary trigger path -- see the
    // file header comment and xiaozhi-c3-pendant-chenglong.md project memory
    // for how this was found (a second known-good unit's live log showed
    // stock firmware receiving this over UART, not reading a GPIO directly).
    void UartListenTask() {
        uart_config_t uart_config = {
            .baud_rate = 9600,
            .data_bits = UART_DATA_8_BITS,
            .parity = UART_PARITY_DISABLE,
            .stop_bits = UART_STOP_BITS_1,
            .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
            .source_clk = UART_SCLK_DEFAULT,
        };
        uart_driver_install(UART_NUM_1, 1024, 0, 0, nullptr, 0);
        uart_param_config(UART_NUM_1, &uart_config);
        uart_set_pin(UART_NUM_1, VENDOR_UART_TX_PIN, VENDOR_UART_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);

        ESP_LOGI(TAG, "UART listen task started (TX=GPIO%d RX=GPIO%d @9600 8N1)",
                 (int)VENDOR_UART_TX_PIN, (int)VENDOR_UART_RX_PIN);

        uint8_t window[kButtonPressPacketLen];
        size_t filled = 0;
        uint8_t byte;
        while (true) {
            int len = uart_read_bytes(UART_NUM_1, &byte, 1, pdMS_TO_TICKS(100));
            if (len <= 0) {
                continue;
            }
            if (filled < kButtonPressPacketLen) {
                window[filled++] = byte;
            } else {
                memmove(window, window + 1, kButtonPressPacketLen - 1);
                window[kButtonPressPacketLen - 1] = byte;
            }
            if (filled == kButtonPressPacketLen &&
                memcmp(window, kButtonPressPacket, kButtonPressPacketLen) == 0) {
                ESP_LOGI(TAG, "UART button-press packet matched -- triggering");
                HandleButtonPress();
                filled = 0;
            }
        }
    }

    static void UartListenTaskEntry(void* arg) {
        static_cast<Esp32C3ChenglongBoard*>(arg)->UartListenTask();
    }

    // 物联网初始化，添加对 AI 可见设备
    void InitializeIot() {
        auto& thing_manager = iot::ThingManager::GetInstance();
        thing_manager.AddThing(iot::CreateThing("Speaker"));

        // LED: GPIO9, 1 pixel (v29, SETTLED) -- empirically confirmed by the
        // v25-v28 GPIO sweep (user saw the real edge light-pipe LED blink
        // ONLY during the GPIO9 test) and consistent with the corrected
        // stock-binary trace (gpio=9, count=1). See config.h for the full
        // story, including why the old "GPIO9 = button" belief was wrong.
        led_strip_ = new CircularStrip(BUILTIN_LED_GPIO, 1);
        thing_manager.AddThing(iot::CreateThing("Battery"));
    }

public:
    Esp32C3ChenglongBoard() {
        // 把 ESP32C3 的 VDD SPI 引脚作为普通 GPIO 口使用
        esp_efuse_write_field_bit(ESP_EFUSE_VDD_SPI_AS_GPIO);

        InitializeCodecI2c();
        InitializeBatteryAdc();
        InitializeIot();

        // Real, production UART listener (v22) -- see UartListenTask above.
        xTaskCreate(UartListenTaskEntry, "uartlisten", 4096, this, 3, nullptr);

    }

    virtual Led* GetLed() override {
        return led_strip_;
    }

    virtual AudioCodec* GetAudioCodec() override {
        static Es8311AudioCodec audio_codec(codec_i2c_bus_, I2C_NUM_0, AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_MCLK, AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS, AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN,
            AUDIO_CODEC_PA_PIN, AUDIO_CODEC_ES8311_ADDR);
        return &audio_codec;
    }

    virtual bool GetBatteryLevel(int& level, bool& charging, bool& discharging) override {
        int adc_value = 0;
        if (adc_oneshot_read(battery_adc_handle_, BATTERY_ADC_CHANNEL, &adc_value) != ESP_OK) {
            return false;
        }
        // Coin-cell (~3V nominal) rough mapping via a 12-bit ADC read;
        // NOT calibrated against this exact PCB's divider yet -- revisit
        // once real battery-voltage-vs-ADC data is available.
        const int kAdcEmpty = 1200;
        const int kAdcFull = 2400;
        if (adc_value <= kAdcEmpty) {
            level = 0;
        } else if (adc_value >= kAdcFull) {
            level = 100;
        } else {
            level = (adc_value - kAdcEmpty) * 100 / (kAdcFull - kAdcEmpty);
        }
        charging = false;
        discharging = true;
        return true;
    }
};

DECLARE_BOARD(Esp32C3ChenglongBoard);
