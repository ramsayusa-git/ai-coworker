#ifndef _WEBSOCKET_PROTOCOL_H_
#define _WEBSOCKET_PROTOCOL_H_


#include "protocol.h"

#include <web_socket.h>
#include <freertos/FreeRTOS.h>
#include <freertos/event_groups.h>

#define WEBSOCKET_PROTOCOL_SERVER_HELLO_EVENT (1 << 0)

class WebsocketProtocol : public Protocol {
public:
    WebsocketProtocol();
    ~WebsocketProtocol();

    void Start() override;
    void SendAudio(const std::vector<uint8_t>& data) override;
    bool OpenAudioChannel() override;
    void CloseAudioChannel() override;
    bool IsAudioChannelOpened() const override;
    void SetAuthToken(const std::string& token) override;
    void SetServerUrl(const std::string& url) override;

private:
    EventGroupHandle_t event_group_handle_;
    WebSocket* websocket_ = nullptr;
    // Populated from the OTA response's "websocket" object when present
    // (see ota.cc); falls back to the Kconfig CONFIG_WEBSOCKET_ACCESS_TOKEN /
    // CONFIG_WEBSOCKET_URL defaults when empty.
    std::string auth_token_override_;
    std::string server_url_override_;

    void ParseServerHello(const cJSON* root);
    bool SendText(const std::string& text) override;
};

#endif
